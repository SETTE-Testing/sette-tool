JaCoCo Java Code Coverage Library
=================================

JaCoCo is a free Java code coverage library distributed under the Eclipse Public
License. Check [http://www.eclemma.org/jacoco](http://www.eclemma.org/jacoco)
for downloads, documentation and feedback.